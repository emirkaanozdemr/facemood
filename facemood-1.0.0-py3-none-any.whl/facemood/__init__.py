from .emotion_predictor import predict_emotion_from_camera
__version__="1.0.0"